$("#example").countdown({
  date: "06/20/2019 23:59:59",
  day: "Day",
  days: "Days"
});
